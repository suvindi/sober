import TimeEntry from '../models/TimeEntry.js';
import mongoose from 'mongoose';


// export const createTimeEntry = async (req, res, next) => {
//   const currentTime = new Date();

//   // Check if there is an existing time entry that has not been stopped
//   const lastTimeEntry = await TimeEntry.findOne({ user: req.user.id, endTime: null });

//   if (lastTimeEntry) {
//     // If there is an existing time entry, update its endTime and calculate the duration
//     lastTimeEntry.endTime = currentTime;
//     lastTimeEntry.duration = (currentTime - lastTimeEntry.startTime) / 1000; // Convert to seconds
//     await lastTimeEntry.save();
//     return res.status(200).json(lastTimeEntry);
//   } else {
//     // If there is no existing time entry, create a new one
//     const newTimeEntry = new TimeEntry({
//       startTime: currentTime,
//       user: req.user.id,
//     });

//     try {
//       const savedTimeEntry = await newTimeEntry.save();
//       return res.status(200).json(savedTimeEntry);
//     } catch (err) {
//       return next(err);
//     }
//   }
// };

// export const stopTimeEntry = async (req, res, next) => {
//   const currentTime = new Date();

//   // Find the last time entry for the current user that has not been stopped
//   const lastTimeEntry = await TimeEntry.findOne({ user: req.user.id, endTime: null });

//   if (lastTimeEntry) {
//     // If there is an existing time entry, update its endTime and calculate the duration
//     lastTimeEntry.endTime = currentTime;
//     lastTimeEntry.duration = (currentTime - lastTimeEntry.startTime) / 1000; // Convert to seconds
//     await lastTimeEntry.save();
//     return res.status(200).json(lastTimeEntry);
//   } else {
//     // If there is no existing time entry, return an error
//     return res.status(400).json({ message: 'No active time entry found' });
//   }
// };

export const createTimeEntry = async (req, res, next) => {
  const currentTime = new Date();

  // Check if there is an existing time entry that has not been stopped
  const lastTimeEntry = await TimeEntry.findOne({ user: req.user.id, endTime: null });

  if (lastTimeEntry) {
    // If there is an existing time entry, update its endTime and calculate the duration
    lastTimeEntry.endTime = currentTime;
    lastTimeEntry.duration = (currentTime - lastTimeEntry.startTime) / 1000; // Convert to seconds
    await lastTimeEntry.save();
    return res.status(200).json(lastTimeEntry);
  } else {
    // If there is no existing time entry, create a new one
    const newTimeEntry = new TimeEntry({
      startTime: currentTime,
      user: req.user.id,
      duration: 0, // Set initial duration to 0 for new time entry
    });

    try {
      const savedTimeEntry = await newTimeEntry.save();
      return res.status(200).json(savedTimeEntry);
    } catch (err) {
      return next(err);
    }
  }
};


export const stopTimeEntry = async (req, res, next) => {
  const currentTime = new Date();
  const { pastTime } = req.body; // Get the pastTime value from the request body

  // Calculate the endTime based on the pastTime value
  const endTime = pastTime ? new Date(currentTime.getTime() + pastTime * 1000) : currentTime;

  // Find the last time entry for the current user that has not been stopped
  const lastTimeEntry = await TimeEntry.findOne({ user: req.user.id, endTime: null });

  if (lastTimeEntry) {
    // If there is an existing time entry, update its endTime and calculate the duration
    lastTimeEntry.endTime = endTime; // Use the endTime calculated from pastTime
    lastTimeEntry.duration = (endTime - lastTimeEntry.startTime) / 1000; // Convert to seconds
    await lastTimeEntry.save();
    return res.status(200).json(lastTimeEntry);
  } else {
    // If there is no existing time entry, return an error
    return res.status(400).json({ message: 'No active time entry found' });
  }
};




export const viewAllDurations = async (req, res, next) => {
  try {
    // Find all time entries for the user
    const timeEntries = await TimeEntry.find({ user: req.user.id });

    // Extract the durations from each entry and include dates and times
    const durations = timeEntries.map((entry) => {
      return {
        duration: entry.duration,
        startTime: new Date(entry.startTime).toLocaleString(),
        endTime: entry.endTime ? new Date(entry.endTime).toLocaleString() : "N/A"
      };
    });

    return res.status(200).json(durations);
  } catch (err) {
    return next(err);
  }
};


export const viewAllDurationsSum = async (req, res, next) => {
  try {
    // Find all time entries for the user
    const timeEntries = await TimeEntry.find({ user: req.user.id });

    // Calculate the sum of durations
    const totalDuration = timeEntries.reduce((acc, entry) => acc + entry.duration, 0);

    return res.status(200).json({ totalDuration });
  } catch (err) {
    return next(err);
  }
};






