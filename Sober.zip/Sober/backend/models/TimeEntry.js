import mongoose from 'mongoose';

const { Schema } = mongoose;

const timeEntrySchema = new Schema({
  startTime: {
    type: Date,
    required: true
  },
  endTime: {
    type: Date,
    required: false // Not required since it will be null until the time entry is stopped
  },
  duration: {
    type: Number,
    required: false // Not required since it will be calculated and added later
  },
  user: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  }
});

export default mongoose.model('TimeEntry', timeEntrySchema);


