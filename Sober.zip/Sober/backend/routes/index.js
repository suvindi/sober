import express from 'express';

import tasksRoutes from './tasks.js';
import authRoutes from './auth.js';
import usersRoutes from './users.js';
import checkAuth from '../utils/checkAuth.js';
import timeRoutes from './times.js'

const router = express.Router();

router.use('/auth', authRoutes);
router.use('/users',checkAuth, usersRoutes);
router.use('/tasks' , checkAuth, tasksRoutes);
router.use('/times' , checkAuth, timeRoutes);

export default router;