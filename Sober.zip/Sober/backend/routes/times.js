import express from 'express';


import  { createTimeEntry , stopTimeEntry , viewAllDurations , viewAllDurationsSum}  from '../controllers/time.js';
const router = express.Router();

router.post('/createTime', createTimeEntry);
router.patch('/stop', stopTimeEntry)
router.get('/viewAllTimes', viewAllDurations)
router.get('/viewAllTimesSum', viewAllDurationsSum)



export default router;