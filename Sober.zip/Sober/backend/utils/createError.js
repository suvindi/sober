export default ({ message, status }) => {
    const error = new Error();
    error.message = message;
    error.statusCode = status;
    return error;
  };

  export const logout = async (req, res) => {
    res.clearCookie('access_token');
    return res.status(200).json({ message: 'logout success' });
  };


  export const isLoggedIn = async (req, res) => {
    const token = req.cookies.access_token;
    if (!token) {
      return res.json(false);
    }
    return jwt.verify(token, process.env.JWT_SECRET, (err) => {
      if (err) {
        return res.json(false);
      }
      return res.json(true);
    });
  };