import React, { useState, useEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import { Route, Routes } from 'react-router-dom';
import alanBtn from '@alan-ai/alan-sdk-web';

import PrivateRoutes from './components/PrivateRoutes';

import EditProfile from './pages/EditProfile';
import Home from './pages/Home';
import TaskList from './components/task/TaskList';

import Start from './pages/Start';
import SignInSide from './pages/signin/SignSide'
import SignUp from './pages/signin/Rejister/SignUp'
import Time from './components/time/Time';
import TimeTracker from './pages/timeTrack/timePicker';
// import alanAI
import CreateTimeEntryForm from './pages/timeTrack/timePicker';
import Videous from './pages/videos';

// const alanKey = '1b0bc24499db47d213f7489487df47172e956eca572e1d8b807a3e2338fdd0dc/stage';

function App() {
 
  // const activeMenu = true;
  
  
  return (
    <>
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            fontSize: '1.8rem',
          },
        }}
      />
      <Routes>
        <Route element={<PrivateRoutes />}>
          <Route path="/" element={<Start />} />
          <Route path="/home" element={<Home />} />
          <Route path="/timess" element={<Time />} />
          <Route path="/instruction" element={<Videous />} />
          <Route path="/edit-profile" element={<EditProfile />} />
          <Route path="/tasklist" component={<TaskList />} />
          
         
        </Route>
        <Route path="/auth" element={<SignInSide />} />
        <Route path="/signUp" element={<SignUp />} />
      </Routes>

    </>
  );
}

export default App;
