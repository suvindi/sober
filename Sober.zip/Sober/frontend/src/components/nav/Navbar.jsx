import { AppBar, Button, Toolbar, Typography } from '@mui/material';
import { FaUserAlt } from 'react-icons/fa';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useEffect, useState } from 'react';
import { toast } from 'react-hot-toast';

export default function Navbar() {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  const getUser = async () => {
    try {
      const { data } = await axios.get('/api/users/me');
      setUser(data);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    getUser();
  }, []);

  const handleLogout = async () => {
    try {
      await axios.get('/api/auth/logout');
      setUser(null);
      toast.success('Logged out successfully');
      navigate('/auth');
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <AppBar position="static">
      <Toolbar>
        <FaUserAlt style={{ fontSize: '2em', marginRight: '1em' }} />
        <Typography variant="h6" sx={{ flexGrow: 1 }}>
          {user?.name}
        </Typography>
        <Link to="/" style={{ textDecoration: 'none', color: 'inherit' }}>
          <Button color="inherit" variant="outlined" style={{ marginRight: '1em' }}>
            Home
          </Button>
        </Link>
        <Link to="/edit-profile" style={{ textDecoration: 'none', color: 'inherit' }}>
          <Button color="inherit" variant="outlined" style={{ marginRight: '1em' }}>
            Edit Profile
          </Button>
        </Link>
        <Button color="inherit" onClick={handleLogout}>
          Logout
        </Button>
      </Toolbar>
    </AppBar>
  );
}
