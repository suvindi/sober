import React, { useState, useEffect } from 'react';
import Layout from '../Layout';
import Navbar from '../nav/Navbar';
import TimeTracker from '../../pages/timeTrack/timePicker';

import alanBtn from '@alan-ai/alan-sdk-web';
const alanKey = '1b0bc24499db47d213f7489487df47172e956eca572e1d8b807a3e2338fdd0dc/stage';

function Time() {

  useEffect(() => {
    alanBtn({
      key: alanKey,
      // onCommand: ({ command }) => {
      //   if (command === 'new') {
      //     alert('This code ');
      //   }
      // },
    });
  }, []);

    return (
      <Layout>
        
        <Navbar />
        
        <TimeTracker />
      </Layout>
    );
  }
  export default Time;