import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import Navbar from '../components/nav/Navbar';
import TaskList from '../components/task/TaskList';
import TimeTracker from './timeTrack/timePicker';

//import '../styles/home.scss';
import alanBtn from '@alan-ai/alan-sdk-web';
const alanKey = '1b0bc24499db47d213f7489487df47172e956eca572e1d8b807a3e2338fdd0dc/stage';

function Home() {

  useEffect(() => {
    alanBtn({
      key: alanKey,
      // onCommand: ({ command }) => {
      //   if (command === 'new') {
      //     alert('This code ');
      //   }
      // },
    });
  }, []);

  //const classes = useStyles();

  
  return (
    <Layout>
      
      <Navbar />
      <TaskList />
      
      
    </Layout>
  );
}
export default Home;