import React, { useState, useEffect } from 'react';
import Navbar from '../components/nav/Navbar';

import SignInSide from './signin/SignSide';
import { Link } from 'react-router-dom';
import { createTheme
  , ThemeProvider } from '@material-ui/core/styles';
import { 
  Box,
  Button, 
  Card, 
  CardContent, 
  CardHeader, 
  Grid, 
  Typography 
} from '@mui/material';
import { makeStyles } from '@mui/styles';

import StickyFooter from '../components/Footer'; 

import alanBtn from '@alan-ai/alan-sdk-web';
const alanKey = '1b0bc24499db47d213f7489487df47172e956eca572e1d8b807a3e2338fdd0dc/stage';

import Slider from 'react-slick';

import image1 from './images/image2.png';
import image2 from './images/image2.png';
import image3 from './images/image2.png';

import MainFeaturedPost from './MainFeaturedPost';

const theme = createTheme({
  palette: {
    primary: {
      main: '#2196f3',
    },
    secondary: {
      main: '#2196f3',
    },
  },
});

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    margin: '0rem',
    padding: '0rem',
   //backgroundImage: 'url("https://images.unsplash.com/photo-1505455184862-554165e5f6ba?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1469&q=80")',
    //backgroundSize: 'cover',
    //minHeight: '100vh',
    backgroundColor: '#f2f2f2',
  },
  card: {
    height: "250px",
    margin: '2rem',
    textAlign: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    borderRadius: '10px',
    boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
    backgroundImage: 'url("https://images.unsplash.com/photo-1540350394557-8d14678e7f91?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1632&q=80")',
    backgroundSize: '100%',
  },
  cardTwo: {
    height: "250px",
    margin: '2rem',
    textAlign: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    borderRadius: '10px',
    boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
    backgroundImage: 'url("https://images.unsplash.com/photo-1501139083538-0139583c060f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80")',
    backgroundSize: '100%',
  },
  cardThree: {
    height: "250px",
    margin: '2rem',
    textAlign: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    borderRadius: '10px',
    boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
    backgroundImage: 'url("https://images.unsplash.com/photo-1505455184862-554165e5f6ba?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1469&q=80")',
    backgroundSize: '100%',
  },
  header: {
    //color: '#fff',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#fff',
    //marginBottom: theme.spacing(4),
   // marginTop: theme.spacing(4),
    textAlign: 'center',
    textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)',
  },
  button: {
    marginTop: '1rem',
    borderRadius: '5px',
    boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.25)',
  },
  footer: {
    //backgroundColor: "grey",
    color: "grey",
    padding: '1px',
    textAlign: 'center',
    position: 'fixed',
    bottom: '0',
    width: '100%',
  },
}));



const mainFeaturedPost = {
  title: 'Welcome to Sober Me App',
  description:
    "Sober me is more than just a free sobriety app. Along with tracking your sober days, it helps you build new habits and connect with an AI voice assistant.",
  image: 'https://source.unsplash.com/random/?blog/',
 
  imageText: 'main image description',
};





function Start() {

  useEffect(() => {
    alanBtn({
      key: alanKey,
      // onCommand: ({ command }) => {
      //   if (command === 'new') {
      //     alert('This code ');
      //   }
      // },
    });
  }, []);

  const classes = useStyles();

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };


  

  

  return (
    
    <Box className={classes.root}>
      <Navbar />
      <MainFeaturedPost post={mainFeaturedPost} />
    
      <Grid container spacing={2} justifyContent="center">
        <Grid item xs={12} sm={4} md={4}>
          <Card className={classes.card}>
            <CardHeader title="Habit Tool & Personal Note."  />
            <CardContent>
              <Typography  variant="h6" fontWeight="bold" color="White" gutterBottom  component="p" paddingBottom={2}>
              Make healthier habits and keep a reminder.
              </Typography>
              <Link to="/home">
                <Button variant="contained" color="primary" className={classes.button}>View Habit Tool</Button>
              </Link>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <Card className={classes.cardTwo}>
            <CardHeader title="Progress tracker and achievement badges." />
            <CardContent>
              <Typography variant="h6" fontWeight="bold" color="White" gutterBottom  component="p" paddingBottom={2}>
              Track hours, days and months they have been sober and keep users motivated.
              </Typography>
              <Link to="/timess">
                <Button variant="contained" color="primary" className={classes.button}>Track Times</Button>
              </Link>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={6}>
          <Card className={classes.cardThree}>
            <CardHeader title="Instructions" />
            <CardContent>
              <Typography variant="h6" fontWeight="bold" color="White" gutterBottom  component="p" paddingBottom={2}>
                Instructions about drug addiction and how to obstain from drugs. Click here , We can help you.
              </Typography>
              <Link to="/instruction">
                <Button variant="contained" color="primary" className={classes.button}>Read more</Button>
              </Link>
              
            </CardContent>
          </Card>
          
        </Grid>
        
      </Grid>
     
    
    <footer className={classes.footer}>
      <Typography variant="body2" color="textSecondary">
    Need help? Our voice assistant is here to assist you. Click on the microphone icon in the bottom right corner to start using it.
  </Typography>
  <Typography variant="body2" color="textSecondary">
    &copy; 2023 Sober Me
  </Typography>
  </footer>
  

  </Box>
  );

  }

  export default Start;
