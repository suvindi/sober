import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Box, Button, CircularProgress, Typography } from '@mui/material';
import Badge from '@mui/material/Badge';
import { styled } from '@mui/material/styles';
import Rating from '@mui/material/Rating';

const TimeTracker = () => {
  const [isTracking, setIsTracking] = useState(false);
  const [duration, setDuration] = useState(null);
  const [loading, setLoading] = useState(false);
  const [totalDuration, setTotalDuration] = useState(0);
  const [durationCount, setDurationCount] = useState(0);
  const [durations, setDurations] = useState([]);
  const [timeEntries, setTimeEntries] = useState([]);
  const [pastTime, setPastTime] = useState('');



  const StyledBadge = styled(Badge)(({ theme }) => ({
    '& .MuiBadge-badge': {
      //backgroundColor: 'green', /* set the background color */
      //color: 'white', /* set the text color */
      fontSize: '12px', /* set the font size */
      fontWeight: 'bold', /* set the font weight */
      borderRadius: '50%', /* set the border radius to make it circular */
      height: '100px', /* set the height */
      width: '500px', /* set the minimum width */
      padding: '10px', /* set the padding */
      boxSizing: 'border-box', /* set the box-sizing */
      display: 'flex', /* display the content as flex */
      alignItems: 'center', /* align the content vertically */
      justifyContent: 'center', /* align the content horizontally */
      position: 'absolute', /* position the badge absolutely */
      top: '100px', /* move the badge up */
      right: '0px', /* move the badge to the right */
    
    },
  }));


const handleStart = async () => {
  setLoading(true);
  try {
    const response = await axios.post('/api/times/createTime', { pastTime }); // Pass the pastTime value in the request body
    setIsTracking(true);
  } catch (error) {
    console.error(error);
  } finally {
    setLoading(false);
  }
};

const handleStop = async () => {
  setLoading(true);
  try {
    const response = await axios.patch('/api/times/stop', { pastTime });
    setIsTracking(false);
    setDuration(response.data.duration);
    setTotalDuration(totalDuration + response.data.duration);
    setDurationCount(durationCount + 1);
    localStorage.setItem('totalDuration', totalDuration + response.data.duration);
  } catch (error) {
    console.error(error);
  } finally {
    setLoading(false);
  }
};

  useEffect(() => {
    displayDurations();
  }, []);

  const displayDurations = async () => {
    try {
      const response = await axios.get('/api/times/viewAllTimes');
      setDurations(response.data); // Set the durations to the state
    } catch (err) {
      console.error(err);
    }
  };
  

  useEffect(() => {
    // Calculate the total duration when the durations state is updated
    const sumDurations = durations.reduce((total, duration) => total + duration, 0);
    setTotalDuration(sumDurations);
  }, [durations]);

  const displayDurationsSum = async () => {
    try {
      const response = await axios.get('/api/times/viewAllTimesSum');
      setDurations(response.data);
    } catch (err) {
      console.error(err);
    }
  };

  const totalDuration1 = durations.reduce((acc, duration) => acc + duration.duration, 0);


  const calculateTotalDuration = (durations) => {
    let totalDuration = 0;
    for (let i = 0; i < durations.length; i++) {
      const durationInSeconds = parseInt(durations[i].duration);
      totalDuration += durationInSeconds;
    }
    const storedTotalDuration = localStorage.getItem('totalDuration');
    if (storedTotalDuration) {
      totalDuration += parseInt(storedTotalDuration);
    }
    return totalDuration;
  }
  //const totalDuration1 = 86400 * 7; // example duration value in seconds



  const getBadgeContent = () => {
    if (totalDuration1 >= 86400 * 30) { // if duration >= 30 days
      return (
        <div>
          <Rating name="very-good" value={5} readOnly size="small" />
          <span> You have been sober for more than 30 days. Great job!</span>
        </div>
      );
    } else if (totalDuration1 >= 86400 * 7) { // if duration >= 7 days
      return (
        <div>
          <Rating name="good" value={4} readOnly size="small" />
          <span><h3> You have been sober for more than 7 days. Well done!</h3></span>
        </div>
      );
    } else { // if duration < 7 days
      return (
        <div>
          <Rating name="start" value={3} readOnly size="small" />
          <h2><span> You have been sober for less than 7 days. Keep doing!</span></h2>
        </div>
      );
    }
  }
  
  const days = Math.floor(totalDuration1 / (3600 * 24)); // Calculate the number of days
const hours = Math.floor((totalDuration1 % (3600 * 24)) / 3600); // Calculate the number of hours
const minutes = Math.floor((totalDuration1 % 3600) / 60); // Calculate the number of minutes
const seconds = (totalDuration1 % 60).toFixed(2); // Calculate the number of seconds
  

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', my: 2 }}>
      <Typography variant="h5" component="h2" mb={2}>
        Time Tracker
      </Typography>
      {isTracking ? (
        <>
          <Typography variant="body1" mb={2}>
            Tracking time...
          </Typography>
          <Button variant="contained" onClick={handleStop} disabled={loading}>
            {loading ? <CircularProgress size={24} /> : 'Stop'}
          </Button>
        </>
      ) : (
        <>
          <Typography variant="body1" mb={2}>
            Click Start to begin tracking your sober time.
          </Typography>
          <Button variant="contained" onClick={handleStart} disabled={loading}>
            {loading ? <CircularProgress size={24} /> : 'Start'}
          </Button>
          <input type="text" value={pastTime} onChange={(e) => setPastTime(e.target.value)} placeholder="Enter past time" />

        </>
      )}
      {duration && (
        <Typography variant="body1" mt={2}>
          Duration: {duration} seconds
        </Typography>
      )}
      {totalDuration > 0 && (
        <Typography variant="body1" mt={2}>
          Total duration: {totalDuration} seconds
        </Typography>
      )}
      {durationCount > 0 && (
        <Typography variant="body1" mt={2}>
          Duration counts: {durationCount}
        </Typography>
      )}
      <div>
      <h1>All Durations</h1>
      <ul>
        {durations.map(duration => (
           <li key={duration._id}>
           Duration: {duration.duration} seconds,  
           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date: {new Date(duration.endTime).toLocaleDateString()}
         </li>
        ))}
      </ul>
      {durations.length > 0 && (
  <Typography variant="body1" mt={2}>
    Total Duration last time: 
    {days > 0 && `${days} days `}
  {hours > 0 && `${hours} hours `}
  {minutes > 0 && `${minutes} minutes `}
  {seconds} seconds
    <div>
    <StyledBadge  badgeContent={getBadgeContent()}>
             
            </StyledBadge>
            </div>
  </Typography>
)}


    </div>
    </Box>
  );
};

export default TimeTracker;

