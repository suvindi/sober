import React, { useState, useEffect } from "react";
import { Box, Grid, Paper, Typography } from "@mui/material";
import Navbar from "../components/nav/Navbar";

const videos = ["Agi2Og4Ig-k", "deIUmxBCdig", "kyUF7T-qhMA" , "DbFPopNOUtw","84ag0fK-kIk","TLKxdTmk-zc"];
import alanBtn from '@alan-ai/alan-sdk-web';
const alanKey = '1b0bc24499db47d213f7489487df47172e956eca572e1d8b807a3e2338fdd0dc/stage';

const Videos = () => {


  useEffect(() => {
    alanBtn({
      key: alanKey,
      // onCommand: ({ command }) => {
      //   if (command === 'new') {
      //     alert('This code ');
      //   }
      // },
    });
  }, []);
  
  return (
    <div>
        <Navbar />
    <Box sx={{ flexGrow: 1, paddingTop:2 }}>
      <Paper elevation={3} sx={{ p: 2 }}>
        <Typography variant="h5" sx={{ mb: 2 }}>
          Instructions Videos
        </Typography>
        <Grid container spacing={2}>
          {videos.map((videoId) => (
            <Grid item xs={12} sm={6} md={4} key={videoId}>
              <Box sx={{ width: "100%", height: "0", position: "relative", paddingBottom: "56.25%" }}>
                <iframe
                  src={`https://www.youtube.com/embed/${videoId}`}
                  title="YouTube video player"
                  width="100%"
                  height="100%"
                  style={{ position: "absolute", top: "0", left: "0" }}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </Box>
            </Grid>
          ))}
        </Grid>
      </Paper>
    </Box>
    </div>
  );
};

export default Videos;


// import React, { useState, useEffect } from "react";
// import { Box, Grid, Paper, Typography } from "@mui/material";

// const API_KEY = "YOUR_YOUTUBE_API_KEY";
// const videos = ["E5_SlS4Q_do", "VIDEO_ID_2", "VIDEO_ID_3"];

// const Videos = () => {
//   const [videoDetails, setVideoDetails] = useState([]);

//   useEffect(() => {
//     const fetchVideoDetails = async () => {
//       const response = await fetch(
//         `https://www.googleapis.com/youtube/v3/videos?id=${videos.join(
//           ","
//         )}&part=snippet&key=${API_KEY}`
//       );
//       const data = await response.json();
//       setVideoDetails(data.items);
//     };

//     fetchVideoDetails();
//   }, []);

//   return (
//     <Box sx={{ flexGrow: 1 }}>
//       <Paper elevation={3} sx={{ p: 2 }}>
//         <Typography variant="h5" sx={{ mb: 2 }}>
//           My Videos
//         </Typography>
//         <Grid container spacing={2}>
//           {videoDetails.map((video) => (
//             <Grid item xs={12} sm={6} md={4} key={video.id}>
//               <Box sx={{ position: "relative", paddingBottom: "56.25%" }}>
//                 <img
//                   src={video.snippet.thumbnails.medium.url}
//                   alt={video.snippet.title}
//                   style={{ position: "absolute", top: "0", left: "0", width: "100%", height: "100%" }}
//                 />
//                 <Box
//                   sx={{
//                     position: "absolute",
//                     top: "0",
//                     left: "0",
//                     width: "100%",
//                     height: "100%",
//                     display: "flex",
//                     alignItems: "center",
//                     justifyContent: "center",
//                     backgroundColor: "rgba(0, 0, 0, 0.5)",
//                     color: "#fff",
//                     cursor: "pointer",
//                     transition: "opacity 0.2s ease-in-out",
//                     "&:hover": {
//                       opacity: 0.8,
//                     },
//                   }}
//                 >
//                   <iframe
//                     src={`https://www.youtube.com/embed/${video.id}`}
//                     title={video.snippet.title}
//                     width="100%"
//                     height="100%"
//                     allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
//                     allowFullScreen
//                   ></iframe>
//                 </Box>
//               </Box>
//             </Grid>
//           ))}
//         </Grid>
//       </Paper>
//     </Box>
//   );
// };

// export default Videos;

